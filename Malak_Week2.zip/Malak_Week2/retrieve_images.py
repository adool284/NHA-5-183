"""Build an artifact image search index from Essam's embedding handoff.

Dependencies: numpy, Pillow and torch; Person 2 supplies DINOv2 and its weights.
Build and compare: python retrieve_images.py build --person2-root PATH --embeddings-dir ESSAM_RUN --output SEARCH_RUN
Search: python retrieve_images.py query --person2-root PATH --index-dir SEARCH_RUN --image PHOTO --top-k 5
The two settings compare maximum reference cosine with mean reference cosine.
Validation chooses the setting and rejection threshold; exposed pilot queries
only measure regression behavior. Results are possible matches, not identities.

Shared helpers: Essam_Week2/week2_common.py. Keep this week's person folders
side by side; extract the complete weekly archive for the runnable layout.
"""

from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import sys


_COMMON_FOLDER = Path(__file__).resolve().parents[1] / "Essam_Week2"
if not (_COMMON_FOLDER / "week2_common.py").is_file():
    raise FileNotFoundError(
        "Missing Essam_Week2/week2_common.py. Extract the complete Week 2 archive, "
        "or extract the person archives into the same folder without renaming their folders."
    )
sys.path.insert(0, str(_COMMON_FOLDER))
from week2_common import calibrate_threshold, encode_rows, export_embeddings, load_core, load_embeddings, load_inputs, make_encoder, output_directory, read_json, sha256, source_fingerprint, write_json


class ImageIndex:
    def __init__(self, rows, vectors):
        self.rows, self.vectors = rows, vectors
        self.labels = sorted({row["artifact_id"] for row in rows})
        self.indices = {label: np.array([index for index, row in enumerate(rows) if row["artifact_id"] == label]) for label in self.labels}

    def rank(self, query, aggregation="max", top_k=5):
        query = np.asarray(query, dtype=np.float32).reshape(-1)
        if query.shape != (384,) or not np.isfinite(query).all() or np.linalg.norm(query) == 0:
            raise ValueError("A query must be a finite nonzero 384-dimensional DINOv2 vector")
        if aggregation not in {"max", "mean"} or top_k < 1:
            raise ValueError("Use max or mean aggregation and a positive top-k")
        query = query / np.linalg.norm(query)
        similarities = np.clip(self.vectors @ query, -1, 1)
        ranked = []
        for label, indices in self.indices.items():
            scores = similarities[indices]
            representative = int(indices[int(scores.argmax())])
            score = scores.max() if aggregation == "max" else scores.mean()
            ranked.append({"artifact_id": label, "similarity": float(score), "reference_image_id": self.rows[representative]["image_id"], "reference_count": len(indices)})
        return sorted(ranked, key=lambda item: (-item["similarity"], item["artifact_id"]))[:min(top_k, len(ranked))]


def evaluate(index, rows, vectors, aggregation, threshold):
    cases = []
    known_ids = set(index.labels)
    for row, vector in zip(rows, vectors):
        ranking = index.rank(vector, aggregation, top_k=5)
        accepted = bool(ranking and ranking[0]["similarity"] >= threshold)
        known = row["artifact_id"] in known_ids
        cases.append({"image_id": row["image_id"], "expected_id": row["artifact_id"], "known": known, "accepted": accepted,
            "status": "possible_match" if accepted else "insufficient_visual_evidence",
            "correct_top1": known and ranking[0]["artifact_id"] == row["artifact_id"], "ranking": ranking})
    return summarize_cases(cases, aggregation, threshold)


def summarize_cases(cases, aggregation, threshold):
    """Summarize saved rankings with a frozen validation rejection threshold."""
    cases = [{**case, "accepted": case["ranking"][0]["similarity"] >= threshold,
        "status": "possible_match" if case["ranking"][0]["similarity"] >= threshold else "insufficient_visual_evidence"} for case in cases]
    known = [case for case in cases if case["known"]]
    unknown = [case for case in cases if not case["known"]]
    recalls = {f"recall_at_{k}": sum(case["expected_id"] in [item["artifact_id"] for item in case["ranking"][:k]] for case in known) / len(known) if known else None for k in (1, 3, 5)}
    successes = [case for case in cases if (case["known"] and case["accepted"] and case["correct_top1"]) or (not case["known"] and not case["accepted"])]
    failures = [case for case in cases if case not in successes]
    return {"aggregation": aggregation, "reject_below": threshold, "known_queries": len(known), "unknown_queries": len(unknown), **recalls,
        "accepted_correct_rate": sum(case["accepted"] and case["correct_top1"] for case in known) / len(known) if known else None,
        "unknown_rejection_rate": sum(not case["accepted"] for case in unknown) / len(unknown) if unknown else None,
        "representative_successes": successes[:3], "representative_failures": failures[:3], "queries": cases}


def build(args):
    root = Path(args.person2_root).resolve()
    output = output_directory(root, args.output)
    accepted_rows, _, evaluations, _, quality = load_inputs(root)
    rows, vectors, manifest = load_embeddings(root, args.embeddings_dir)
    expected = {row["image_id"]: (row["artifact_id"], row["sha256"]) for row in accepted_rows}
    actual = {row["image_id"]: (row["artifact_id"], row["sha256"]) for row in rows}
    if actual != expected or len(rows) != len(expected):
        raise ValueError("Embedding handoff must contain exactly the accepted photographic references")
    index = ImageIndex(rows, vectors)
    export_embeddings(root, output, rows, vectors)
    encoder = make_encoder(root)
    validation_vectors = encode_rows(root, evaluations["validation"], encoder, args.batch_size)
    settings = {}
    for aggregation in ("max", "mean"):
        rankings = [index.rank(vector, aggregation, 5) for vector in validation_vectors]
        threshold, calibration = calibrate_threshold(
            [ranking[0]["similarity"] for ranking in rankings],
            [row["artifact_id"] == ranking[0]["artifact_id"] for row, ranking in zip(evaluations["validation"], rankings)],
            [row["artifact_id"] in index.indices for row in evaluations["validation"]])
        settings[aggregation] = {"reject_below": threshold, "calibration": calibration}
    chosen = max(("max", "mean"), key=lambda name: (settings[name]["calibration"].get("balanced_accuracy") or 0, name == "max"))
    # Freeze the selected setting before encoding or scoring pilot test queries.
    config = {"schema_version": 1, "source_fingerprint": source_fingerprint(root), "aggregation": chosen,
        "reject_below": settings[chosen]["reject_below"], "settings": settings,
        "embedding_manifest_sha256": sha256(output / "embedding_manifest.json"),
        "score_note": "Cosine similarity is not a probability; accepted results are possible matches",
        "evaluation_scope": quality["limitation"], "threshold_policy": "Validation score midpoints; balanced known-correct acceptance and unknown rejection; stricter boundary wins ties"}
    write_json(output / "index_config.json", config)
    reports = {"validation": {name: evaluate(index, evaluations["validation"], validation_vectors, name, settings[name]["reject_below"]) for name in settings}}
    for split in ("pilot_test", "tutankhamun_regression"):
        features = encode_rows(root, evaluations[split], encoder, args.batch_size)
        reports[split] = {name: evaluate(index, evaluations[split], features, name, settings[name]["reject_below"]) for name in settings}
    write_json(output / "retrieval_evaluation.json", {"source_fingerprint": manifest["source_fingerprint"], "chosen_setting": chosen, "scope": quality["limitation"], "comparison": reports})
    write_json(output / "query_manifest.json", {"source_fingerprint": manifest["source_fingerprint"], "use": "Exposed validation/pilot regression queries; not independent final tests", **evaluations})
    print(json.dumps({"output": str(output), "artifact_count": len(index.labels), "reference_count": len(rows), "chosen_setting": chosen, "threshold": config["reject_below"], "pilot_recall_at_1": reports["pilot_test"][chosen]["recall_at_1"]}), flush=True)


def query(args):
    root, directory = Path(args.person2_root).resolve(), Path(args.index_dir)
    config = read_json(directory / "index_config.json")
    if config["source_fingerprint"] != source_fingerprint(root) or sha256(directory / "embedding_manifest.json") != config["embedding_manifest_sha256"]:
        raise ValueError("Image index belongs to a different dataset or has changed")
    rows, vectors, _ = load_embeddings(root, directory)
    image = load_core(root).decode(Path(args.image).read_bytes())
    vector = make_encoder(root).encode([image])[0]
    ranking = ImageIndex(rows, vectors).rank(vector, config["aggregation"], args.top_k)
    accepted = bool(ranking and ranking[0]["similarity"] >= config["reject_below"])
    result = {"status": "possible_matches" if accepted else "insufficient_visual_evidence",
        "artifact_id": ranking[0]["artifact_id"] if accepted else None,
        "matches": ranking if accepted else [], "best_candidate": ranking[0] if ranking else None,
        "reject_below": config["reject_below"], "aggregation": config["aggregation"], "score_note": config["score_note"]}
    print(json.dumps(result, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    building = commands.add_parser("build", help="Build the index and compare the two similarity settings")
    building.add_argument("--person2-root", required=True)
    building.add_argument("--embeddings-dir", required=True)
    building.add_argument("--output", required=True)
    building.add_argument("--batch-size", type=int, default=8)
    searching = commands.add_parser("query", help="Rank unique artifact IDs for a photograph")
    searching.add_argument("--person2-root", required=True)
    searching.add_argument("--index-dir", required=True)
    searching.add_argument("--image", required=True)
    searching.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()
    if args.command == "build":
        if args.batch_size < 1:
            parser.error("batch-size must be positive")
        build(args)
    else:
        if args.top_k < 1:
            parser.error("top-k must be positive")
        query(args)


if __name__ == "__main__":
    main()
