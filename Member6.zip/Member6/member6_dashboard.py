"""Egyptian Museum Visitor Analytics Dashboard.
Run: python -m streamlit run member6_dashboard.py
Reads analytics files from the member6_outputs folder.
"""
from pathlib import Path
import json
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

BASE_DIR = Path(__file__).resolve().parent
OUT = BASE_DIR / "member6_outputs"

st.set_page_config(page_title="Egyptian Museum | Visitor Analytics", page_icon="🏺", layout="wide", initial_sidebar_state="expanded")

st.markdown(r"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');
:root{--gold:#f0b84e;--gold2:#bd8335;--sand:#ffe0a0;--night:#030b12;--panel:#071722;--teal:#26b6b0;--blue:#3c9fe8;--purple:#9664dc;}
.stApp{background:radial-gradient(ellipse at 78% 3%,#392818 0%,#101a20 25%,#030b12 66%,#02070c 100%);color:#f7ead0}
[data-testid="stHeader"]{background:transparent}
.block-container{padding-top:1rem;padding-bottom:1rem;max-width:1800px}
html,body,[class*="css"]{font-family:'Inter',sans-serif}
h1,h2,h3{color:var(--sand)!important;font-family:'Cinzel',serif!important}
.egypt-header{position:relative;overflow:hidden;min-height:132px;padding:23px 28px 20px 30px;margin:0 0 16px;border:1px solid #b98236;border-radius:5px;background:linear-gradient(90deg,rgba(2,10,16,.98) 0%,rgba(7,21,28,.96) 48%,rgba(31,22,14,.92) 100%);box-shadow:0 8px 25px #0009}
.egypt-header:before{content:'𓆣 𓋹 𓂀 𓆣 𓇳 𓋹 𓂀';position:absolute;right:16px;top:6px;font-size:30px;letter-spacing:9px;color:#e4a43e;opacity:.22;white-space:nowrap}
.egypt-header:after{content:'𓃭 𓊹 𓆙 𓋹 𓏏 𓆣 𓂀';position:absolute;left:22px;bottom:3px;font-size:19px;letter-spacing:12px;color:#d89b3b;opacity:.48}
.header-grid{display:flex;align-items:center;gap:20px;position:relative;z-index:1}
.header-icon{font-size:52px;color:#f2b84f;text-shadow:0 0 16px #f2b84f55;min-width:62px;text-align:center}
.eyebrow{font-size:10px;letter-spacing:4px;color:#c9974a;text-transform:uppercase}
.hero-title{font-family:'Cinzel',serif;color:#ffd88a;font-size:clamp(27px,3vw,43px);line-height:1.1;margin:5px 0 2px;text-shadow:0 2px 12px #d08a2d35}
.hero-sub{font-family:'Cinzel',serif;color:#e6c58d;font-size:17px}
.header-motto{margin-left:auto;text-align:right;color:#e7c98e;font-family:'Cinzel',serif;font-style:italic;font-size:14px;line-height:1.8;min-width:145px}
.metric-card{position:relative;overflow:hidden;background:linear-gradient(145deg,rgba(8,28,39,.98),rgba(3,12,19,.98));border:1px solid #986b31;border-radius:11px;padding:15px 16px 12px;min-height:122px;box-shadow:inset 0 0 0 1px #dba64b14,0 5px 15px #0007}
.metric-card:after{content:'𓋹';position:absolute;right:10px;bottom:-14px;font-size:44px;color:#c48b35;opacity:.12}
.metric-label{color:#ead9b9;font-family:'Cinzel',serif;font-size:13px;line-height:1.4}
.metric-value{font-family:'Cinzel',serif;color:#ffd27a;font-size:34px;margin-top:6px;line-height:1.1}
.metric-note{color:#94b7b6;font-size:10px;margin-top:7px}
.metric-symbol{float:left;font-size:31px;color:#f3bd58;margin-right:10px;margin-top:3px;text-shadow:0 0 12px #e9ac4a35}
.panel{background:linear-gradient(145deg,rgba(5,22,32,.96),rgba(3,12,19,.97));border:1px solid #93672f;border-radius:10px;padding:15px 16px 12px;margin-bottom:13px;box-shadow:inset 0 0 0 1px #dba64b10,0 5px 14px #0005;position:relative}
.panel-title{color:#ffd482;font-family:'Cinzel',serif;font-size:17px;margin-bottom:3px}
.panel-sub{color:#a8b9ba;font-size:10px;margin-bottom:7px}
.small-note{color:#9db3b1;font-size:11px}
.ornament{color:#c38c3d;letter-spacing:8px;text-align:center;opacity:.8;font-size:18px;padding:3px}
.insight{border:1px solid #76552d;border-left:3px solid #e6ad4c;background:linear-gradient(90deg,#e5ae4c13,#071722);border-radius:6px;padding:11px 12px;margin:8px 0;color:#eadcc5;font-size:12px}
.insight b{color:#ffd27a}
section[data-testid="stSidebar"]{background:linear-gradient(180deg,#101b20 0%,#050d13 55%,#080e12 100%);border-right:1px solid #9a6c31}
section[data-testid="stSidebar"]>div{padding-top:12px}
section[data-testid="stSidebar"] [data-testid="stRadio"] label{padding:10px 11px;border:1px solid #a477391f;border-radius:6px;margin:4px 0;background:linear-gradient(90deg,#e4ac4510,#0000);transition:all .15s}
section[data-testid="stSidebar"] [data-testid="stRadio"] label:hover{background:#c18a3530;border-color:#d7a64e}
section[data-testid="stSidebar"] [data-testid="stRadio"] label p{font-family:'Cinzel',serif;font-size:12px;color:#f4dfb5}
section[data-testid="stSidebar"] [data-testid="stRadio"] [aria-checked="true"]+div{color:#fff}
section[data-testid="stSidebar"] *{color:#f1e4cc}
.stButton button{background:linear-gradient(90deg,#c28a38,#f2c568);color:#101316;border:1px solid #f5d68b;font-family:'Cinzel',serif;font-weight:700}
.stButton button:hover{background:#f6d58c;color:#101316;border-color:#ffe7ae}
hr{border-color:#76552f}
[data-testid="stDataFrame"]{border:1px solid #70512d;border-radius:6px}
footer{visibility:hidden}
</style>
""", unsafe_allow_html=True)

@st.cache_data(ttl=20)
def read_csv(path: str):
    p = Path(path)
    if p.exists():
        try:
            return pd.read_csv(p, low_memory=False)
        except Exception:
            return pd.DataFrame()
    return pd.DataFrame()

@st.cache_data(ttl=20)
def read_json(path: str):
    p = Path(path)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

report = read_json(str(OUT / "member6_analytics_report.json"))
quality = read_csv(str(OUT / "artifact_data_quality.csv"))
events = read_csv(str(OUT / "combined_clean_event_logs.csv"))
features = read_csv(str(OUT / "visitor_or_session_features.csv"))
artifacts = read_csv(str(OUT / "clean_artifact_analytics_dataset.csv"))

# Header
st.markdown("""
<div class="egypt-header"><div class="header-grid">
  <div class="header-icon">𓂀</div><div>
    <div class="eyebrow">𓋹 &nbsp; Ancient Heritage · Modern Intelligence &nbsp; 𓋹</div>
    <div class="hero-title">Egyptian Museum</div>
    <div class="hero-sub">Visitor Analytics Dashboard</div>
  </div><div class="header-motto">Explore · Learn · Be Inspired<br><span style="font-size:25px;font-style:normal">𓆣 𓇳 𓋹</span></div>
</div></div>
""", unsafe_allow_html=True)

artifact_count = report.get("clean_artifact_records", len(artifacts))
event_count = report.get("real_event_rows_loaded", len(events))
entity_count = report.get("visitor_or_session_feature_rows", len(features))

# Sidebar navigation styled like an Egyptian museum plaque
with st.sidebar:
    st.markdown("<div style='text-align:center;font-size:40px;color:#f1b84e;font-family:Cinzel,serif'>𓆣</div><div style='text-align:center;font-family:Cinzel,serif;color:#ffd27a;font-size:16px'>EGYPTIAN MUSEUM</div><div style='text-align:center;color:#a98a5a;font-size:10px;letter-spacing:3px'>𓋹 ANCIENT WISDOM 𓋹</div><hr>", unsafe_allow_html=True)
    page = st.radio("NAVIGATION", ["⌂  Overview", "▤  Data Quality", "♙  Visitor Behavior", "𓎆  Quiz Analytics", "⚙  ML Monitoring", "♧  Visitor Segmentation", "✧  Insights & Takeaways"], label_visibility="collapsed")
    st.markdown("<div class='ornament'>𓏏 𓂀 𓋹</div><hr>", unsafe_allow_html=True)
    if st.button("↻  Refresh Dashboard", use_container_width=True):
        st.cache_data.clear()
        st.rerun()
    st.markdown("<div style='text-align:center;color:#bd9356;font-family:Cinzel,serif;font-size:12px;margin-top:14px'>𓃭 Ancient Art<br>Modern Intelligence</div>", unsafe_allow_html=True)

page_key = page.split("  ", 1)[-1].strip()
PLOT = dict(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(color="#eadcc2", family="Inter"), margin=dict(l=8, r=8, t=24, b=8))

def style_fig(fig, height=300):
    fig.update_layout(**PLOT, height=height, legend=dict(bgcolor="rgba(0,0,0,0)"))
    fig.update_xaxes(gridcolor="rgba(220,190,140,.12)", zerolinecolor="rgba(220,190,140,.15)")
    fig.update_yaxes(gridcolor="rgba(220,190,140,.12)", zerolinecolor="rgba(220,190,140,.15)")
    return fig

def panel_open(title, subtitle=""):
    st.markdown(f"<div class='panel'><div class='panel-title'>{title}</div><div class='panel-sub'>{subtitle}</div>", unsafe_allow_html=True)

def panel_close():
    st.markdown("</div>", unsafe_allow_html=True)

def event_counts():
    counts = report.get("event_counts_by_type", {}) or {}
    if not counts and not events.empty and "event" in events.columns:
        counts = events["event"].fillna("unknown").astype(str).value_counts().to_dict()
    return counts

def quality_chart(height=290):
    if not quality.empty and {"Field", "Missing %"}.issubset(quality.columns):
        q = quality.copy()
        q["Missing %"] = pd.to_numeric(q["Missing %"], errors="coerce").fillna(0)
        q = q.sort_values("Missing %", ascending=True).tail(10)
        fig = px.bar(q, x="Missing %", y="Field", orientation="h", text=q["Missing %"].map(lambda v: f"{v:.1f}%"), color="Missing %", color_continuous_scale=["#24aaa6", "#e9bd59", "#d17b42"])
        fig.update_layout(**PLOT, height=height, coloraxis_showscale=False, xaxis_title="Missing values (%)", yaxis_title="")
        fig.update_traces(textposition="outside", cliponaxis=False)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Run the analytics pipeline to populate the data quality chart.")

if page_key == "Overview":
    k1, k2, k3, k4 = st.columns(4)
    cards = [
        (k1, "ARTIFACT RECORDS", f"{artifact_count:,}", "Catalog records available", "𓊹"),
        (k2, "RECORDED EVENTS", f"{event_count:,}", "Observed event rows", "𓎆"),
        (k3, "VISITOR SESSIONS", f"{entity_count:,}", "Analyzed interaction sessions", "♙"),
        (k4, "QUIZ ACCURACY", (f"{float(pd.to_numeric(features[[c for c in features.columns if any(x in c.lower() for x in ['accuracy','correct_rate','quiz_score'])][0]], errors='coerce').dropna().mean()):.0%}" if not features.empty and any(any(x in c.lower() for x in ["accuracy", "correct_rate", "quiz_score"]) for c in features.columns) and not pd.to_numeric(features[[c for c in features.columns if any(x in c.lower() for x in ["accuracy", "correct_rate", "quiz_score"])][0]], errors="coerce").dropna().empty else "—"), "From recorded quiz features only", "𓆣"),
    ]
    for col, label, value, note, symbol in cards:
        with col:
            st.markdown(f"<div class='metric-card'><div class='metric-symbol'>{symbol}</div><div class='metric-label'>{label}</div><div class='metric-value'>{value}</div><div class='metric-note'>{note}</div></div>", unsafe_allow_html=True)

    st.write("")
    a, b, c = st.columns([1.08, 1.0, 1.08])
    with a:
        panel_open("𓏏  Data Quality Overview", "Missing values across artifact metadata fields")
        if not quality.empty and {"Field", "Missing %"}.issubset(quality.columns):
            q = quality.copy(); q["Missing %"] = pd.to_numeric(q["Missing %"], errors="coerce").fillna(0)
            complete = max(0, 100 - float(q["Missing %"].mean()))
            fig = go.Figure(go.Pie(labels=["Available", "Missing"], values=[complete, 100-complete], hole=.68, marker=dict(colors=["#e9ae43", "#287fbd"], line=dict(color="#06121a", width=3)), textinfo="none"))
            fig.add_annotation(text=f"{complete:.1f}%<br><span style='font-size:11px'>Average<br>Completeness</span>", showarrow=False, font=dict(size=23, color="#ffdb86", family="Cinzel"))
            fig.update_layout(**PLOT, height=220, showlegend=True, legend=dict(orientation="h", y=-.08, x=.03))
            st.plotly_chart(fig, use_container_width=True)
            st.caption("Completeness is averaged across fields; individual fields vary.")
        else:
            st.info("Data quality details will appear after the analytics pipeline runs.")
        panel_close()
    with b:
        panel_open("𓆣  Event Type Distribution", "Counts from recorded event logs")
        counts = event_counts()
        if counts:
            ef = pd.DataFrame({"Event": list(counts.keys()), "Count": list(counts.values())}).sort_values("Count", ascending=True)
            fig = px.bar(ef, x="Count", y="Event", orientation="h", text="Count", color="Event", color_discrete_sequence=["#e9ae43", "#269fca", "#28a99a", "#8d68ce", "#d37b48"])
            fig.update_layout(**PLOT, height=275, showlegend=False, xaxis_title="Recorded rows", yaxis_title="")
            fig.update_traces(textposition="outside", cliponaxis=False)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No recorded events are available yet.")
        panel_close()
    with c:
        panel_open("𓂀  Visitor Activity", "Recorded event volume by event type")
        counts = event_counts()
        if counts:
            ef = pd.DataFrame({"Event": list(counts.keys()), "Count": list(counts.values())})
            fig = px.pie(ef, names="Event", values="Count", hole=.48, color_discrete_sequence=["#e9ae43", "#269fca", "#28a99a", "#8d68ce", "#d37b48"])
            fig.update_traces(textposition="inside", textinfo="percent", marker=dict(line=dict(color="#06121a", width=3)))
            fig.update_layout(**PLOT, height=275, legend=dict(orientation="h", y=-.1))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("More recorded events will enrich this chart.")
        panel_close()

    x, y = st.columns([1.3, 1])
    with x:
        panel_open("𓋹  Key Insights", "Evidence-based next steps from the available data")
        insights = report.get("insights", []) or []
        if not insights:
            insights = ["Review metadata fields with the highest missing-value rates.", "Improve artifact descriptions to support search and retrieval.", "Validate image links for a richer artifact exploration experience.", "Record recommendation impressions and clicks to calculate CTR.", "Add latency, error, and confidence fields to operational logs."]
        for i, item in enumerate(insights[:5], 1):
            st.markdown(f"<div class='insight'><b>𓋹 &nbsp; {i:02d}</b> &nbsp; {item}</div>", unsafe_allow_html=True)
        panel_close()
    with y:
        panel_open("𓆣  Ancient Wisdom · Modern Intelligence", "Explore the stories behind the data")
        st.markdown("<div style='text-align:center;padding:14px 4px 8px;font-family:Cinzel,serif;color:#f5d18b;font-size:24px;line-height:1.55'>𓂀<br>Every artifact has a story.<br><span style='font-size:17px'>Every interaction adds a clue.</span><br>𓋹</div>", unsafe_allow_html=True)
        st.caption("Explore artifact discovery patterns and recorded visitor interactions.")
        panel_close()

elif page_key == "Data Quality":
    panel_open("𓏏  Artifact Metadata Completeness", "Inspect missing values and prioritize metadata enrichment")
    if not quality.empty:
        st.dataframe(quality, use_container_width=True, hide_index=True)
        quality_chart(max(360, 24*len(quality)))
    else:
        st.info("The data quality file was not found. Run the analytics pipeline first.")
    panel_close()
    if not artifacts.empty:
        panel_open("𓊹  Artifact Catalog Preview", "A sample of cleaned catalog records")
        st.dataframe(artifacts.head(12), use_container_width=True, hide_index=True)
        panel_close()

elif page_key == "Visitor Behavior":
    counts = event_counts()
    panel_open("𓆣  Visitor Journey", "Observed sequence of interaction events")
    if counts:
        order = ["quiz_started", "question_served", "answer_submitted", "quiz_completed"]
        names = [x for x in order if x in counts] + [x for x in counts if x not in order]
        cols = st.columns(min(len(names), 4))
        symbols = ["▷", "?", "✓", "☆"]
        for i, name in enumerate(names):
            with cols[i % len(cols)]:
                st.markdown(f"<div class='metric-card' style='text-align:center;min-height:100px'><div style='font-size:27px;color:#f0b84e'>{symbols[i%len(symbols)]}</div><div class='metric-label'>{name.replace('_',' ').title()}</div><div class='metric-value' style='font-size:27px'>{counts[name]}</div></div>", unsafe_allow_html=True)
    else:
        st.info("The visitor journey will appear as real event logs are collected.")
    panel_close()
    left, right = st.columns(2)
    with left:
        panel_open("𓎆  Event Frequency", "How often each observed event appears")
        if counts:
            df = pd.DataFrame({"Event": list(counts.keys()), "Count": list(counts.values())})
            fig = px.bar(df, x="Event", y="Count", text="Count", color="Event", color_discrete_sequence=["#e9ae43", "#269fca", "#28a99a", "#8d68ce"])
            st.plotly_chart(style_fig(fig, 300), use_container_width=True)
        else: st.info("No event data available.")
        panel_close()
    with right:
        panel_open("𓋹  Session Feature Snapshot", "Available numeric visitor/session features")
        numeric = features.select_dtypes(include="number") if not features.empty else pd.DataFrame()
        if not numeric.empty:
            st.dataframe(numeric.describe().T.reset_index().rename(columns={"index":"Feature"}), use_container_width=True, hide_index=True)
        else: st.info("Numeric visitor/session features will appear as more interactions are recorded.")
        panel_close()
    if not events.empty:
        with st.expander("View recorded event rows"):
            st.dataframe(events, use_container_width=True, hide_index=True)

elif page_key == "Quiz Analytics":
    panel_open("𓎆  Quiz Performance Observatory", "Quiz metrics are derived only from recorded sessions and answers")
    quiz_cols = [c for c in features.columns if any(x in c.lower() for x in ["quiz", "accuracy", "correct", "answer", "question", "score"])] if not features.empty else []
    if quiz_cols:
        st.dataframe(features[quiz_cols], use_container_width=True, hide_index=True)
        numeric_cols = [c for c in quiz_cols if pd.api.types.is_numeric_dtype(features[c])]
        if numeric_cols:
            selected = st.selectbox("Explore a quiz metric", numeric_cols)
            vals = pd.to_numeric(features[selected], errors="coerce").dropna()
            if not vals.empty:
                fig = px.histogram(pd.DataFrame({selected: vals}), x=selected, nbins=12, color_discrete_sequence=["#e9ae43"])
                st.plotly_chart(style_fig(fig, 300), use_container_width=True)
    else:
        st.info("Quiz analytics will appear when quiz-related features are present in the session data.")
    if not events.empty and "event" in events.columns:
        quiz_events = events[events["event"].astype(str).str.contains("quiz|question|answer", case=False, na=False)]
        if not quiz_events.empty:
            st.markdown("<div class='panel-title'>Recorded Quiz Activity</div>", unsafe_allow_html=True)
            vc = quiz_events["event"].astype(str).value_counts().rename_axis("Event").reset_index(name="Count")
            fig = px.bar(vc, x="Event", y="Count", text="Count", color="Event", color_discrete_sequence=["#e9ae43", "#269fca", "#28a99a", "#8d68ce"])
            st.plotly_chart(style_fig(fig, 280), use_container_width=True)
            st.dataframe(quiz_events, use_container_width=True, hide_index=True)
    panel_close()

elif page_key == "ML Monitoring":
    panel_open("⚙  ML Operational Observatory", "Track model and service performance signals")
    candidates = [c for c in events.columns if any(k in c.lower() for k in ["latency", "duration_ms", "response_time", "confidence", "error", "failed", "status_code"])] if not events.empty else []
    if candidates:
        st.dataframe(events[candidates].head(100), use_container_width=True, hide_index=True)
        numeric = [c for c in candidates if pd.api.types.is_numeric_dtype(events[c])]
        if numeric:
            selected = st.selectbox("Choose an available monitoring field", numeric)
            vals = pd.to_numeric(events[selected], errors="coerce").dropna()
            if not vals.empty:
                m1, m2 = st.columns(2)
                m1.metric(f"Average {selected}", f"{vals.mean():.2f}")
                m2.metric(f"Recorded values", f"{len(vals):,}")
                fig = px.histogram(pd.DataFrame({selected: vals}), x=selected, color_discrete_sequence=["#e9ae43"])
                st.plotly_chart(style_fig(fig, 280), use_container_width=True)
    else:
        st.info("Performance charts will appear as monitoring metrics are added to the analytics feed.")
    panel_close()
    panel_open("𓋹  Model Improvement Checklist", "Useful monitoring signals to add to future logs")
    for text in ["Record response latency in milliseconds.", "Track failed requests and error categories.", "Store confidence scores for computer-vision predictions.", "Log unsupported retrieval questions for review.", "Track recommendation impressions and clicks separately."]:
        st.markdown(f"<div class='insight'>𓋹 &nbsp; {text}</div>", unsafe_allow_html=True)
    panel_close()

elif page_key == "Visitor Segmentation":
    panel_open("♧  Visitor Segmentation Explorer", "Explore visitor behavior patterns and engagement features")
    numeric = features.select_dtypes(include="number") if not features.empty else pd.DataFrame()
    if not numeric.empty:
        st.dataframe(numeric.describe().T.reset_index().rename(columns={"index":"Feature"}), use_container_width=True, hide_index=True)
        chosen = st.selectbox("Choose a feature to explore", list(numeric.columns))
        vals = pd.to_numeric(numeric[chosen], errors="coerce").dropna()
        if not vals.empty:
            fig = px.histogram(pd.DataFrame({chosen: vals}), x=chosen, nbins=10, color_discrete_sequence=["#e9ae43"])
            st.plotly_chart(style_fig(fig, 300), use_container_width=True)
    else:
        st.info("The visitor feature table is ready to support segmentation as more real interaction records become available.")
    panel_close()
    panel_open("𓂀  Segment Interpretation", "Behavior-based groups should be evaluated against sufficient real visitor data")
    st.markdown("<div style='font-family:Cinzel,serif;color:#ffd482;font-size:18px;text-align:center;padding:12px'>Explore · Learn · Discover · Return</div>", unsafe_allow_html=True)
    st.caption("Explore engagement patterns to support more personalized museum experiences.")
    panel_close()

elif page_key == "Insights & Takeaways":
    panel_open("✧  Key Insights & Recommendations", "Evidence-based actions for stronger discovery and personalization")
    insights = report.get("insights", []) or []
    if not insights:
        insights = ["Review metadata fields with the highest missing-value rates.", "Improve artifact descriptions to support search and retrieval.", "Validate image links for a richer artifact exploration experience.", "Record recommendation impressions and clicks to calculate CTR.", "Add latency, error, and confidence fields to operational logs."]
    for i, item in enumerate(insights[:8], 1):
        st.markdown(f"<div class='insight'><b>𓋹 &nbsp; {i:02d}</b> &nbsp; {item}</div>", unsafe_allow_html=True)
    panel_close()
st.markdown("<div class='ornament'>𓋹 𓆣 𓂀 𓇳 𓂀 𓆣 𓋹</div><hr><div style='text-align:center;color:#c79a52;font-family:Cinzel,serif;padding:5px'>EGYPTIAN MUSEUM · VISITOR INSIGHTS<br><span style='font-family:Inter,sans-serif;font-size:10px;color:#819b99'>Ancient Art · Modern Intelligence</span></div>", unsafe_allow_html=True)
