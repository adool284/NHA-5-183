"""
Member 6 — Visitor Behavior Analytics & ML Pipeline
Uses real museum artifact metadata and optional real event logs.
IMPORTANT: Artifact metadata is not visitor behavior. If event logs are absent,
the pipeline reports that visitor segmentation/operational metrics cannot yet
be computed; it does not fabricate visitors or metrics.

Run:
    python member6_visitor_analytics.py
Optional event files (place beside this script):
    interaction_logs.csv / interaction_logs.jsonl
    recommendation_events.csv / recommendation_events.jsonl
    quiz_events.csv / quiz_events.jsonl
    rag_monitoring_logs.csv / rag_monitoring_logs.jsonl
All event files may also be combined into events.csv or events.jsonl.
"""
from __future__ import annotations

import json
import time
import traceback
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

try:
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "member6_outputs"
ARTIFACTS_FILE_CANDIDATES = [
    BASE_DIR / "combined_rag_dataset.csv",
    BASE_DIR / "combined_museum_artifacts_final_with_license.csv",
]
EVENT_FILE_NAMES = [
    "events.csv", "events.jsonl",
    "interaction_logs.csv", "interaction_logs.jsonl",
    "recommendation_events.csv", "recommendation_events.jsonl",
    "quiz_events.csv", "quiz_events.jsonl",
    "rag_monitoring_logs.csv", "rag_monitoring_logs.jsonl",
    "monitoring_logs.csv", "monitoring_logs.jsonl",
    "visitor_monitoring_events.csv", "visitor_monitoring_events.jsonl",
]

def load_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".jsonl", ".ndjson"}:
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        rows.append(obj)
                except json.JSONDecodeError:
                    print(f"Warning: skipped invalid JSON on {path.name}:{line_no}")
        return pd.DataFrame(rows)
    raise ValueError(f"Unsupported file type: {path}")

def find_artifacts() -> tuple[pd.DataFrame, Path]:
    for path in ARTIFACTS_FILE_CANDIDATES:
        if path.exists():
            df = pd.read_csv(path)
            return df, path
    raise FileNotFoundError(
        "Could not find combined_rag_dataset.csv or "
        "combined_museum_artifacts_final_with_license.csv beside this script."
    )

def load_event_logs() -> tuple[pd.DataFrame, list[str]]:
    frames, loaded = [], []
    for name in EVENT_FILE_NAMES:
        path = BASE_DIR / name
        if path.exists():
            try:
                df = load_table(path)
                if not df.empty:
                    df["_source_file"] = name
                    frames.append(df)
                    loaded.append(name)
            except Exception as exc:
                print(f"Warning: could not load {name}: {exc}")
    if not frames:
        return pd.DataFrame(), loaded
    # Preserve heterogeneous event schemas; missing fields remain null.
    return pd.concat(frames, ignore_index=True, sort=False), loaded

def clean_artifact_data(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    data = df.copy()
    data.columns = [str(c).strip() for c in data.columns]
    text_cols = data.select_dtypes(include=["object"]).columns
    for col in text_cols:
        data[col] = data[col].map(lambda x: x.strip() if isinstance(x, str) else x)
    before = len(data)
    if "Artifact ID" in data.columns:
        data = data.drop_duplicates(subset=["Artifact ID"], keep="first")
    else:
        data = data.drop_duplicates()
    missing = data.isna().sum().to_dict()
    quality = {
        "rows_before_deduplication": int(before),
        "rows_after_deduplication": int(len(data)),
        "duplicates_removed": int(before - len(data)),
        "missing_values_by_column": {k: int(v) for k, v in missing.items()},
        "missing_percent_by_column": {
            k: round(float(v / max(len(data), 1) * 100), 2)
            for k, v in missing.items()
        },
    }
    return data, quality

def make_artifact_quality_outputs(artifacts: pd.DataFrame, quality: dict[str, Any]) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    artifacts.to_csv(OUTPUT_DIR / "clean_artifact_analytics_dataset.csv", index=False)
    missing = pd.Series(quality["missing_percent_by_column"]).sort_values(ascending=False)
    if len(missing):
        plt.figure(figsize=(10, 5))
        missing.plot(kind="bar")
        plt.ylabel("Missing values (%)")
        plt.title("Museum artifact metadata completeness")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "artifact_metadata_completeness.png", dpi=160)
        plt.close()

    # Actual distribution of artifact classes, if the column exists.
    if "Project Class" in artifacts.columns:
        counts = artifacts["Project Class"].fillna("Unknown").value_counts().head(15)
        plt.figure(figsize=(10, 5))
        counts.sort_values().plot(kind="barh")
        plt.xlabel("Number of artifacts")
        plt.title("Artifacts by project class")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "artifacts_by_class.png", dpi=160)
        plt.close()

def normalize_events(events: pd.DataFrame) -> pd.DataFrame:
    if events.empty:
        return events.copy()
    out = events.copy()
    # Standardize common alternative field names without discarding original columns.
    aliases = {
        "visitorId": "visitor_id", "user_id": "visitor_id", "userId": "visitor_id",
        "sessionId": "session_id", "timestamp_utc": "timestamp",
        "event_name": "event", "event_type": "event",
        "latency": "latency_ms", "response_time_ms": "latency_ms",
        "response_latency_ms": "latency_ms", "isCorrect": "is_correct",
        "accuracyPercentage": "accuracy_percentage", "voiceUsed": "voice_used",
        "recommended_artifact_id": "artifact_id",
    }
    for old, new in aliases.items():
        if old in out.columns and new not in out.columns:
            out = out.rename(columns={old: new})
    if "timestamp" in out.columns:
        out["timestamp"] = pd.to_datetime(out["timestamp"], errors="coerce", utc=True)
    if "event" in out.columns:
        out["event"] = out["event"].astype("string").str.strip().str.lower()
    return out

def visitor_level_features(events: pd.DataFrame) -> pd.DataFrame:
    """Aggregate genuine logs at visitor level, or session level when no visitor ID exists.

    A session is NOT treated as a unique person. The output records entity_type so
    downstream analysis cannot silently confuse sessions with visitors.
    """
    if events.empty:
        return pd.DataFrame()
    e = events.copy()
    if "visitor_id" in e.columns and e["visitor_id"].notna().any():
        group_col, entity_type = "visitor_id", "visitor"
    elif "session_id" in e.columns and e["session_id"].notna().any():
        group_col, entity_type = "session_id", "session"
    else:
        return pd.DataFrame()
    e = e.dropna(subset=[group_col]).copy()
    if e.empty:
        return pd.DataFrame()
    e[group_col] = e[group_col].astype(str)
    grouped = e.groupby(group_col, dropna=False)
    features = grouped.size().rename("total_interactions").to_frame()
    ev = e.get("event", pd.Series("", index=e.index)).fillna("").astype(str).str.lower()
    e["_is_recommendation_click"] = ev.str.contains(r"recommendation.*click|recommendation_clicked|rec_click", regex=True)
    e["_is_quiz_answer"] = ev.isin(["answer_submitted", "quiz_answer", "quiz_answered"]) | ev.str.contains("answer_submitted", regex=False)
    e["_is_quiz_question"] = ev.eq("question_served")
    e["_is_quiz_start"] = ev.eq("quiz_started")
    e["_is_quiz_complete"] = ev.eq("quiz_completed")
    for col, name in [
        ("_is_recommendation_click", "recommendation_clicks"),
        ("_is_quiz_answer", "quiz_answers_submitted"),
        ("_is_quiz_question", "quiz_questions_served"),
        ("_is_quiz_start", "quizzes_started"),
        ("_is_quiz_complete", "quizzes_completed"),
    ]:
        features[name] = e.groupby(group_col)[col].sum()
    if "is_correct" in e.columns:
        truth = e["is_correct"].map(lambda x: float(str(x).strip().lower() in {"true", "1", "yes", "correct"}) if pd.notna(x) else np.nan)
        e["_correct_numeric"] = truth
        features["quiz_accuracy"] = e.loc[e["_is_quiz_answer"]].groupby(group_col)["_correct_numeric"].mean()
    if "language" in e.columns:
        features["preferred_language"] = e.groupby(group_col)["language"].agg(
            lambda col: col.dropna().astype(str).str.lower().mode().iloc[0] if not col.dropna().empty else np.nan
        )
    if "latency_ms" in e.columns:
        e["_latency"] = pd.to_numeric(e["latency_ms"], errors="coerce")
        features["avg_latency_ms"] = e.groupby(group_col)["_latency"].mean()
    if "voice_used" in e.columns:
        voice = e["voice_used"].map(lambda x: float(str(x).strip().lower() in {"true", "1", "yes"}) if pd.notna(x) else np.nan)
        e["_voice"] = voice
        features["voice_use_rate"] = e.groupby(group_col)["_voice"].mean()
    features = features.reset_index().rename(columns={group_col: "entity_id"})
    features.insert(1, "entity_type", entity_type)
    features["engagement_score"] = features["total_interactions"]
    features["engagement_score"] += 2 * features["recommendation_clicks"].fillna(0)
    return features

def cluster_visitors(features: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    if features.empty:
        return features, {"status": "not_run", "reason": "No visitor_id/session_id field or no event rows to aggregate."}
    numeric = [
        c for c in ["total_interactions", "recommendation_clicks",
                    "quiz_answers_submitted", "quiz_questions_served", "quizzes_completed",
                    "quiz_accuracy", "avg_latency_ms", "voice_use_rate", "engagement_score"]
        if c in features.columns and pd.to_numeric(features[c], errors="coerce").notna().sum() >= 3
    ]
    if not SKLEARN_AVAILABLE:
        return features, {"status": "not_run", "reason": "scikit-learn is not installed."}
    if len(features) < 6 or len(numeric) < 2:
        return features, {
            "status": "not_run",
            "reason": f"Need at least 6 analysis entities and 2 usable numeric features; found {len(features)} {features['entity_type'].iloc[0] if 'entity_type' in features.columns and len(features) else 'entities'} and {len(numeric)} features.",
            "numeric_features": numeric,
        }
    x = features[numeric].apply(pd.to_numeric, errors="coerce")
    x = x.replace([np.inf, -np.inf], np.nan)
    # Median imputation from observed visitor data only.
    x = x.fillna(x.median()).fillna(0)
    scaled = StandardScaler().fit_transform(x)
    max_k = min(6, len(features) - 1)
    candidate_scores = {}
    best_k, best_score = None, -1
    for k in range(2, max_k + 1):
        labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(scaled)
        if len(set(labels)) > 1 and len(set(labels)) < len(features):
            score = float(silhouette_score(scaled, labels))
            candidate_scores[str(k)] = round(score, 4)
            if score > best_score:
                best_k, best_score = k, score
    if best_k is None:
        return features, {"status": "not_run", "reason": "Could not find a valid clustering configuration."}
    model = KMeans(n_clusters=best_k, random_state=42, n_init=10)
    out = features.copy()
    out["visitor_segment_id"] = model.fit_predict(scaled)
    summary = out.groupby("visitor_segment_id")[numeric].mean().round(3)
    out["visitor_segment"] = out["visitor_segment_id"].map(
        {int(idx): f"Behavior segment {int(idx)}" for idx in summary.index}
    )
    return out, {
        "status": "completed",
        "visitor_count": int(len(out)),
        "features_used": numeric,
        "selected_k": int(best_k),
        "silhouette_score": round(float(best_score), 4),
        "silhouette_scores_by_k": candidate_scores,
        "segment_means": summary.reset_index().to_dict(orient="records"),
        "note": "Segments are labeled by cluster ID, not assigned semantic personas automatically."
    }

def summarize_operations(events: pd.DataFrame) -> dict[str, Any]:
    if events.empty:
        return {"status": "not_available", "reason": "No real operational/event logs were found."}
    out = {"status": "computed_from_logs", "event_rows": int(len(events))}
    if "latency_ms" in events.columns:
        lat = pd.to_numeric(events["latency_ms"], errors="coerce").dropna()
        if len(lat):
            out["latency_ms"] = {
                "count": int(len(lat)),
                "mean": round(float(lat.mean()), 2),
                "median": round(float(lat.median()), 2),
                "p95": round(float(lat.quantile(.95)), 2),
                "max": round(float(lat.max()), 2),
            }
    if "status" in events.columns:
        status = events["status"].astype(str).str.lower()
        failures = status.isin(["error", "failed", "failure", "exception", "500", "false"])
        out["request_status"] = {
            "status_values": status.value_counts().to_dict(),
            "failed_rows": int(failures.sum()),
            "error_rate_percent": round(float(failures.mean() * 100), 2),
        }
    if "fallback_used" in events.columns:
        fb = events["fallback_used"].map(
            lambda x: str(x).strip().lower() in {"true", "1", "yes"}
            if pd.notna(x) else np.nan
        ).dropna()
        if len(fb):
            out["fallback_rate_percent"] = round(float(fb.mean() * 100), 2)
    if "grounding_passed" in events.columns:
        gp = events["grounding_passed"].map(
            lambda x: str(x).strip().lower() in {"true", "1", "yes"}
            if pd.notna(x) else np.nan
        ).dropna()
        if len(gp):
            out["grounding_pass_rate_percent"] = round(float(gp.mean() * 100), 2)
    if "hybrid_score" in events.columns:
        score = pd.to_numeric(events["hybrid_score"], errors="coerce").dropna()
        if len(score):
            out["hybrid_score"] = {"count": int(len(score)), "mean": round(float(score.mean()), 4)}
    return out

def create_behavior_charts(features: pd.DataFrame, clustered: pd.DataFrame) -> None:
    if not features.empty:
        for col in ["total_interactions", "recommendation_clicks", "quiz_accuracy", "avg_latency_ms"]:
            if col in features.columns:
                values = pd.to_numeric(features[col], errors="coerce").dropna()
                if values.empty:
                    continue
                plt.figure(figsize=(8, 4))
                values.plot(kind="hist", bins=min(20, max(5, int(np.sqrt(len(values))))))
                plt.xlabel(col.replace("_", " ").title())
                plt.ylabel("Visitors")
                plt.title(f"Visitor distribution: {col.replace('_', ' ').title()}")
                plt.tight_layout()
                plt.savefig(OUTPUT_DIR / f"visitor_{col}_distribution.png", dpi=160)
                plt.close()
    if not clustered.empty and "visitor_segment" in clustered.columns:
        counts = clustered["visitor_segment"].value_counts()
        plt.figure(figsize=(8, 4))
        counts.plot(kind="bar")
        plt.ylabel("Visitors")
        plt.title("Visitor behavior segments")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "visitor_segments.png", dpi=160)
        plt.close()

def build_insights(artifacts: pd.DataFrame, quality: dict[str, Any],
                   events: pd.DataFrame, features: pd.DataFrame,
                   ops: dict[str, Any]) -> list[str]:
    insights = []
    n = max(len(artifacts), 1)
    missing_pct = quality.get("missing_percent_by_column", {})
    for col in ["License", "Description", "Image URL", "Period", "Dynasty"]:
        if col in missing_pct:
            pct = missing_pct[col]
            insights.append(f"Artifact metadata: {pct:.1f}% of records have no {col} value. Review this field for data-quality improvement before using it in recommendations or quizzes.")
    if not events.empty and "language" in events.columns:
        lang = events["language"].dropna().astype(str).str.lower().value_counts(normalize=True)
        if len(lang):
            top_lang = str(lang.index[0])
            insights.append(f"Observed event logs: {top_lang} is the most frequently recorded language ({lang.iloc[0]*100:.1f}% of events with language values). Validate language support against this observed mix.")
    has_rec_click_events = (not events.empty and "event" in events.columns and events["event"].fillna("").astype(str).str.lower().str.contains(r"recommendation.*click|recommendation_clicked|rec_click", regex=True).any())
    if has_rec_click_events and not features.empty and "recommendation_clicks" in features.columns:
        clicks = pd.to_numeric(features["recommendation_clicks"], errors="coerce")
        insights.append(f"Observed recommendation activity: mean recorded recommendation clicks is {clicks.mean():.2f} per analysis entity across {clicks.notna().sum()} entities. This is not a click-through rate unless recommendation impressions are also logged.")
    if not features.empty and "quiz_accuracy" in features.columns:
        acc = pd.to_numeric(features["quiz_accuracy"], errors="coerce").dropna()
        if len(acc):
            insights.append(f"Observed quiz accuracy averages {acc.mean()*100:.1f}% across {len(acc)} visitors with correctness events; consider reviewing difficulty only alongside sample size and question difficulty.")
    if "latency_ms" in ops:
        latency = ops["latency_ms"]
        insights.append(f"Observed latency from logs: median {latency['median']:.1f} ms and p95 {latency['p95']:.1f} ms across {latency['count']} measured events; investigate the p95 tail if it exceeds your product SLA.")
    if "fallback_rate_percent" in ops:
        insights.append(f"Observed fallback rate is {ops['fallback_rate_percent']:.1f}%; review fallback-triggering queries and retrieval scores.")
    answer_events = events[events["event"].astype(str).str.lower().eq("answer_submitted")] if not events.empty and "event" in events.columns else pd.DataFrame()
    if not answer_events.empty and "is_correct" in answer_events.columns:
        correctness = answer_events["is_correct"].map(lambda x: str(x).strip().lower() in {"true", "1", "yes", "correct"} if pd.notna(x) else np.nan).dropna()
        if len(correctness):
            insights.append(f"Quiz sample: {int(correctness.sum())}/{len(correctness)} recorded answers were correct ({correctness.mean()*100:.1f}%). This sample is too small to infer overall learning or difficulty; continue collecting answer events by question and difficulty.")
    # Do not invent behavior findings when no event logs exist.
    if events.empty:
        insights.append("Visitor-behavior insight unavailable: no visitor interaction, quiz, recommendation, or monitoring event logs were included. Connect real Member 3/4/5 logs before claiming behavior trends.")
    # A report can contain more than five evidence-based data-quality/observed insights.
    return insights

def run_member6_pipeline() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    artifact_raw, artifact_path = find_artifacts()
    artifacts, quality = clean_artifact_data(artifact_raw)
    make_artifact_quality_outputs(artifacts, quality)

    raw_events, loaded_files = load_event_logs()
    events = normalize_events(raw_events)
    if not events.empty:
        events.to_csv(OUTPUT_DIR / "combined_clean_event_logs.csv", index=False)
    features = visitor_level_features(events)
    clustered, cluster_metrics = cluster_visitors(features)
    if not clustered.empty:
        clustered.to_csv(OUTPUT_DIR / "visitor_analytics_dataset.csv", index=False)
        clustered.to_csv(OUTPUT_DIR / "visitor_or_session_analytics_dataset.csv", index=False)
    create_behavior_charts(features, clustered)
    operations = summarize_operations(events)
    insights = build_insights(artifacts, quality, events, features, operations)

    if not features.empty:
        features.to_csv(OUTPUT_DIR / "visitor_features.csv", index=False)
        features.to_csv(OUTPUT_DIR / "visitor_or_session_features.csv", index=False)

    event_counts = {}
    if not events.empty and "event" in events.columns:
        event_counts = {str(k): int(v) for k, v in events["event"].fillna("unknown").value_counts().items()}
    report = {
        "pipeline": "Member 6 — Visitor Behavior Analytics & ML Pipeline",
        "artifact_source_file": artifact_path.name,
        "artifact_rows": int(len(artifacts)),
        "artifact_data_quality": quality,
        "event_files_loaded": loaded_files,
        "event_log_rows": int(len(events)),
        "visitor_or_session_feature_rows": int(len(features)),
        "analysis_entity_type": str(features["entity_type"].iloc[0]) if not features.empty and "entity_type" in features.columns else "unavailable",
        "event_counts_by_type": event_counts,
        "clustering": cluster_metrics,
        "operational_metrics": operations,
        "insights": insights,
        "limitations": [
            "Museum artifact metadata is not visitor behavior data.",
            "No synthetic visitors, fake request counts, or hard-coded latency/grounding scores are generated.",
            "Member handoff JSON files describe interfaces/configuration; they are not runtime event logs.",
            "Recommendation CTR requires impression and click events; click events alone are insufficient.",
            "Retrieval MRR requires labeled relevance judgments; it is not computed from artifact metadata alone."
        ],
    }
    (OUTPUT_DIR / "member6_analytics_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    with (OUTPUT_DIR / "member6_analytics_report.md").open("w", encoding="utf-8") as f:
        f.write("# Member 6 — Visitor Behavior Analytics Report\n\n")
        f.write(f"- Artifact source: `{artifact_path.name}`\n")
        f.write(f"- Clean artifact records: **{len(artifacts)}**\n")
        f.write(f"- Real event rows loaded: **{len(events)}**\n")
        f.write(f"- Visitor/session feature rows: **{len(features)}**\n")
        f.write(f"- Analysis entity type: **{report['analysis_entity_type']}** (session is not equivalent to a unique visitor)\n")
        f.write(f"- Event types: `{json.dumps(event_counts, ensure_ascii=False)}`\n\n")
        f.write("## Data quality\n\n")
        f.write("| Field | Missing values | Missing % |\n|---|---:|---:|\n")
        for col, count in quality["missing_values_by_column"].items():
            f.write(f"| {col} | {count} | {quality['missing_percent_by_column'][col]:.2f}% |\n")
        f.write("\n## Visitor clustering\n\n")
        f.write("```json\n" + json.dumps(cluster_metrics, ensure_ascii=False, indent=2, default=str) + "\n```\n")
        f.write("\n## Operational metrics\n\n")
        f.write("```json\n" + json.dumps(operations, ensure_ascii=False, indent=2, default=str) + "\n```\n")
        f.write("\n## Actionable insights\n\n")
        for i, insight in enumerate(insights, 1):
            f.write(f"{i}. {insight}\n")
        f.write("\n## Limitations and integration notes\n\n")
        for item in report["limitations"]:
            f.write(f"- {item}\n")
    print(f"Artifact source: {artifact_path.name}")
    print(f"Clean artifact records: {len(artifacts)}")
    print(f"Event files loaded: {loaded_files or 'None'}")
    print(f"Real event rows: {len(events)}")
    print(f"Visitor/session feature rows: {len(features)}")
    print(f"Analysis entity type: {report['analysis_entity_type']}")
    print(f"Event counts: {event_counts}")
    print(f"Clustering status: {cluster_metrics.get('status')} — {cluster_metrics.get('reason', 'completed')}")
    print(f"Outputs written to: {OUTPUT_DIR}")
    print("Important: no visitor behavior or operational metrics are fabricated.")

if __name__ == "__main__":
    run_member6_pipeline()
