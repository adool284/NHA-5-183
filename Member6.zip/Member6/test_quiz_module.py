"""Tests for quiz_module.py. Run: python test_quiz_module.py"""
import json
import tempfile
from pathlib import Path

import quiz_module as q

IDS = ["MET_2021.41.2", "MET_2021.41.15", "MET_2021.41.18", "MET_2021.41.106"]
results = []


def check(name, condition):
    results.append((name, bool(condition)))
    print(f"{'PASS' if condition else 'FAIL'} - {name}")


def play(session, n, correct=True):
    out = []
    for _ in range(n):
        ques = q.generate_quiz_question(session)
        if ques.get("status") != "ok":
            break
        server_q = session["pending"]
        if correct:
            answer = server_q["_correct_answer"]
        else:
            answer = next(o for o in ques["options"] if o != server_q["_correct_answer"])
        out.append((ques, q.submit_answer(session, answer)))
    return out


# 1. Basic question shape + scope + no answer leaked
s = q.start_quiz_session(IDS, seed=1)
ques = q.generate_quiz_question(s)
check("4 unique options, target in scope",
      len(ques["options"]) == 4 and len({o.casefold() for o in ques["options"]}) == 4
      and ques["artifact_id"] in IDS)
check("Public question does not leak the answer",
      not any(k.startswith("_") or k == "correct_answer" for k in ques))

# 2. Answer validation
srv = s["pending"]
check("Correct answer accepted", q.check_answer(srv, srv["_correct_answer"]))
check("Invalid answer rejected", not q.check_answer(srv, "__not_an_option__"))
bad = q.submit_answer(s, "__not_an_option__")
check("Invalid submit does not count", bad["valid_answer"] is False and s["questions_answered"] == 0)
res = q.submit_answer(s, srv["_correct_answer"])
check("Result has evidence + source URL + validation",
      res["source"]["source_url"] and res["source"]["evidence"]
      and res["source"]["validated_against"] == "RAG Text")

# 3. Quality: 600 questions, no ambiguous options, no uncertain facts, fact validated
amb = unc = invalid = total = 0
for seed in range(150):
    sess = q.start_quiz_session(IDS, seed=seed)
    sess["level"] = q.LEVELS[seed % 3]
    for _ in range(4):
        ques = q.generate_quiz_question(sess)
        if ques.get("status") != "ok":
            break
        total += 1
        sv = sess["pending"]
        correct = sv["_source"]["fact_value"]
        unc += "?" in correct
        field = ques["field"]
        amb += any(o != sv["_correct_answer"] and q.conflicts(field, correct, o) for o in ques["options"])
        row = q.get_dataset().set_index("Artifact ID").loc[ques["artifact_id"]].to_dict()
        invalid += not q.validate_fact(row, field, correct)
        q.submit_answer(sess, sv["_correct_answer"])
check(f"No ambiguous distractors ({total} questions)", amb == 0)
check("No uncertain ('?') facts used", unc == 0)
check("Every served fact validated against RAG Text", invalid == 0)

# 4. No repeats + exhaustion
s2 = q.start_quiz_session(IDS, seed=3)
seen, status = [], None
for _ in range(40):
    ques = q.generate_quiz_question(s2)
    if ques.get("status") != "ok":
        status = ques["status"]
        break
    seen.append((ques["artifact_id"], ques["field"]))
    q.submit_answer(s2, s2["pending"]["_correct_answer"])
check("No repeated (artifact, field) question", len(seen) == len(set(seen)))
check("Quiz ends cleanly when facts are exhausted", status == "no_more_questions" and len(seen) > 0)

# 5. Pending question is stable until answered
s3 = q.start_quiz_session(IDS, seed=4)
a, b = q.generate_quiz_question(s3), q.generate_quiz_question(s3)
check("Unanswered question is not replaced", a["question_id"] == b["question_id"])

# 6. Reproducibility
r1 = q.generate_quiz_question(q.start_quiz_session(IDS, seed=99))
r2 = q.generate_quiz_question(q.start_quiz_session(IDS, seed=99))
check("Same seed -> same question", (r1["artifact_id"], r1["field"], r1["options"]) ==
      (r2["artifact_id"], r2["field"], r2["options"]))

# 7. Adaptive difficulty
inc = q.start_quiz_session(IDS, seed=5)
play(inc, 2, correct=True)
check("Difficulty up after 2 correct", inc["level"] == "medium")
play(inc, 1, correct=False)
check("Difficulty down after wrong", inc["level"] == "easy")
mx = q.start_quiz_session(IDS, seed=6)
mx["level"] = "hard"
play(mx, 2, correct=True)
check("Maximum level respected", mx["level"] == "hard")
mn = q.start_quiz_session(IDS, seed=7)
play(mn, 1, correct=False)
check("Minimum level respected", mn["level"] == "easy")
hard_q = q.start_quiz_session(IDS, seed=8)
hard_q["level"] = "hard"
easy_q = q.start_quiz_session(IDS, seed=8)
def avg_sim(sess):
    vals = []
    for _ in range(3):
        ques = q.generate_quiz_question(sess)
        sv = sess["pending"]
        vals += [q._similarity(sv["_correct_answer"], o) for o in ques["options"] if o != sv["_correct_answer"]]
        q.submit_answer(sess, sv["_correct_answer"])
    return sum(vals) / len(vals)
check("Hard distractors are more similar than easy ones", avg_sim(hard_q) > avg_sim(easy_q))

# 8. Scope + inputs
check("Quiz scope = supplied IDs", set(s["artifact_ids"]) == set(IDS))
partial = q.start_quiz_session(IDS + ["NOT_AN_ID"], seed=1)
check("Unknown IDs reported, not crashing", partial["missing_ids"] == ["NOT_AN_ID"])
for bad_input, label in ((None, "None"), ([], "empty list")):
    try:
        q.start_quiz_session(bad_input)
        check(f"Visited IDs {label} rejected", False)
    except ValueError:
        check(f"Visited IDs {label} rejected", True)
try:
    q.start_quiz_session(["NOT_AN_ID"])
    check("All-unknown IDs rejected", False)
except ValueError:
    check("All-unknown IDs rejected", True)

# 9. Visited-only distractor scope falls back honestly
vs = q.start_quiz_session(IDS, seed=2, distractor_scope="visited")
vq = q.generate_quiz_question(vs)
check("distractor_scope_used is reported", vq["distractor_scope_used"] in {"visited", "dataset"})

# 10. Arabic
ar = q.start_quiz_session(IDS, language="ar", seed=1)
aq = q.generate_quiz_question(ar)
check("Arabic question text", any("\u0600" <= c <= "\u06FF" for c in aq["question"]))
try:
    q.start_quiz_session(IDS, language="fr")
    check("Unsupported language rejected", False)
except ValueError:
    check("Unsupported language rejected", True)

# 11. JSON-serialisable session + events for Member 6
sj = q.start_quiz_session(IDS, seed=11, voice_used=True)
play(sj, 3, correct=True)
summary = q.finish_quiz(sj)
check("Session is JSON-serialisable", bool(json.dumps(sj, ensure_ascii=False)))
names = [e["event"] for e in sj["events"]]
check("Events: quiz_started/question_served/answer_submitted/quiz_completed",
      names[0] == "quiz_started" and "question_served" in names
      and "answer_submitted" in names and names[-1] == "quiz_completed")
need = {"session_id", "language", "voice_used", "timestamp", "event"}
check("Events carry language + voice_used + session_id", all(need <= set(e) for e in sj["events"]))
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "events.jsonl"
    q.export_events_jsonl(sj, path)
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    check("JSONL export", len(lines) == len(sj["events"]) and json.loads(lines[0])["event"] == "quiz_started")
check("Finished quiz serves nothing", q.generate_quiz_question(sj)["status"] == "quiz_finished")

passed = sum(ok for _, ok in results)
print(f"\nTests passed: {passed}/{len(results)}")
raise SystemExit(0 if passed == len(results) else 1)
