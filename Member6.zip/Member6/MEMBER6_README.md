# Member 6 — Visitor Behavior Analytics & ML Pipeline

## What this module does

- Cleans the real museum artifact catalog (`combined_rag_dataset.csv`) and reports missing metadata.
- Loads real interaction / recommendation / quiz / RAG monitoring logs from CSV or JSONL.
- Recognizes Member 4 quiz events: `quiz_started`, `question_served`, `answer_submitted`, `quiz_completed`.
- Produces event counts, session/visitor feature tables, charts, and a JSON + Markdown report.
- Runs K-Means segmentation only when there are at least 6 analysis entities and at least 2 usable numeric features. Otherwise it clearly explains why clustering was skipped.
- Does not fabricate visitor IDs, traffic, latency, grounding rates, or recommendation CTR.

## Files expected beside the script

Required:
- `combined_rag_dataset.csv` (included in this package)

Optional event files, automatically detected:
- `events.csv` / `events.jsonl`
- `interaction_logs.csv` / `interaction_logs.jsonl`
- `recommendation_events.csv` / `recommendation_events.jsonl`
- `quiz_events.csv` / `quiz_events.jsonl`
- `rag_monitoring_logs.csv` / `rag_monitoring_logs.jsonl`
- `monitoring_logs.csv` / `monitoring_logs.jsonl`
- `visitor_monitoring_events.csv` / `visitor_monitoring_events.jsonl`

For Member 4, call `quiz_module.export_events_jsonl(session, "quiz_events.jsonl")` after a quiz session. Make sure not to export the same session repeatedly because the function appends all session events each time.

## Install

```bash
pip install -r member6_requirements.txt
```

## Run

```bash
python member6_visitor_analytics.py
```

## Outputs

Generated in `member6_outputs/`:
- `clean_artifact_analytics_dataset.csv`
- `combined_clean_event_logs.csv` (when event logs are available)
- `visitor_or_session_features.csv`
- `visitor_or_session_analytics_dataset.csv` (when features exist)
- `artifact_metadata_completeness.png`
- `artifacts_by_class.png`
- visitor distribution charts (when the relevant data exists)
- `member6_analytics_report.json`
- `member6_analytics_report.md`

## Important interpretation notes

- A `session_id` is not the same as a unique person. If no `visitor_id` is supplied, the pipeline reports session-level features and labels them as sessions.
- The provided sample event log has 4 events from 1 quiz session. It can validate ingestion and quiz event summaries, but it is far too small for visitor clustering or population-level conclusions.
- To analyze real visitor behavior, the application should pass a stable pseudonymous `visitor_id` where appropriate and log interaction events consistently across Member 1, Member 3, Member 4, and Member 5.
- Recommendation CTR requires both impression and click events. Retrieval MRR requires labeled relevance judgments.
