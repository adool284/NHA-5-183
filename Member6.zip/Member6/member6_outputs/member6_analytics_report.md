# Member 6 — Visitor Behavior Analytics Report

- Artifact source: `combined_rag_dataset.csv`
- Clean artifact records: **1418**
- Event files loaded: `visitor_monitoring_events.jsonl`
- Real event rows loaded: **4**
- Visitor/session feature rows: **1**
- Analysis entity type: **session**
- Event types: `{"quiz_started": 1, "question_served": 1, "answer_submitted": 1, "quiz_completed": 1}`

## Data quality

| Field | Missing values | Missing % |
|---|---:|---:|
| Artifact ID | 0 | 0.00% |
| Museum | 0 | 0.00% |
| Object Number | 0 | 0.00% |
| Title | 0 | 0.00% |
| Project Class | 0 | 0.00% |
| Period | 67 | 4.72% |
| Dynasty | 372 | 26.23% |
| Date | 0 | 0.00% |
| Material | 0 | 0.00% |
| Description | 756 | 53.31% |
| Image URL | 523 | 36.88% |
| Source URL | 0 | 0.00% |
| License | 1351 | 95.28% |
| RAG Text | 0 | 0.00% |

## Visitor clustering

```json
{
  "status": "not_run",
  "reason": "Need at least 6 analysis entities and 2 varying numeric features; found 1 entities and 0 usable features.",
  "numeric_features": []
}
```

## Actionable insights

1. Artifact metadata: 95.3% of records have no usable value for License. Review this field before using it in recommendations or quizzes.
2. Artifact metadata: 53.3% of records have no usable value for Description. Review this field before using it in recommendations or quizzes.
3. Artifact metadata: 36.9% of records have no usable value for Image URL. Review this field before using it in recommendations or quizzes.
4. Artifact metadata: 26.2% of records have no usable value for Dynasty. Review this field before using it in recommendations or quizzes.
5. Artifact metadata: 4.7% of records have no usable value for Period. Review this field before using it in recommendations or quizzes.
6. Observed event logs: 4 unique/retained event rows loaded. Event counts: {'quiz_started': 1, 'question_served': 1, 'answer_submitted': 1, 'quiz_completed': 1}.
7. Quiz accuracy averages 100.0% across 1 analysis entities with recorded correctness. Interpret cautiously; event volume and question difficulty matter.
8. Quiz sample: 1/1 recorded answers were correct (100.0%). This is a sample result, not a population estimate.

## Limitations and integration notes

- Artifact metadata is not visitor behavior data.
- No synthetic visitor records or hard-coded operational metrics are generated.
- A session is not equivalent to a unique visitor.
- Recommendation CTR requires both impression and click events.
- Latency and error rates require corresponding operational log fields.
- Retrieval MRR requires labeled relevance judgments.
