"""
Member 6 — Visitor Behavior Analytics & ML Pipeline
Uses the real artifact catalog and real event logs when available.
Does not edit Member 3/4/5 code and does not generate synthetic visitor data.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "member6_outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

ARTIFACT_CANDIDATES = [
    "combined_rag_dataset.csv",
    "clean_artifact_analytics_dataset.csv",
]
EVENT_CANDIDATES = [
    "visitor_monitoring_events.jsonl",
    "quiz_events.jsonl",
    "events.jsonl",
    "interaction_logs.jsonl",
    "recommendation_events.jsonl",
    "rag_monitoring_logs.jsonl",
    "monitoring_logs.jsonl",
    "visitor_monitoring_events.csv",
    "quiz_events.csv",
    "events.csv",
    "interaction_logs.csv",
    "recommendation_events.csv",
    "rag_monitoring_logs.csv",
    "monitoring_logs.csv",
]

def first_existing(names: Iterable[str]) -> Path | None:
    for name in names:
        candidate = BASE_DIR / name
        if candidate.exists() and candidate.is_file():
            return candidate
    return None

def load_artifacts() -> tuple[pd.DataFrame, str | None]:
    path = first_existing(ARTIFACT_CANDIDATES)
    if path is None:
        return pd.DataFrame(), None
    df = pd.read_csv(path, low_memory=False)
    df.columns = [str(c).strip() for c in df.columns]
    # Remove only exact duplicate rows; don't invent missing metadata.
    df = df.drop_duplicates().copy()
    if "Artifact ID" in df.columns:
        df["Artifact ID"] = df["Artifact ID"].astype("string").str.strip()
    return df, path.name

def load_one_event_file(path: Path) -> pd.DataFrame:
    try:
        if path.suffix.lower() == ".csv":
            return pd.read_csv(path, low_memory=False)
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for line_number, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                    if isinstance(item, dict):
                        item["_source_file"] = path.name
                        rows.append(item)
                except json.JSONDecodeError:
                    print(f"Warning: invalid JSON in {path.name}, line {line_number}; skipped.")
        return pd.DataFrame(rows)
    except (OSError, pd.errors.ParserError, UnicodeDecodeError) as exc:
        print(f"Warning: couldn't read {path.name}: {exc}")
        return pd.DataFrame()

def load_events() -> tuple[pd.DataFrame, list[str]]:
    frames, loaded = [], []
    for name in EVENT_CANDIDATES:
        path = BASE_DIR / name
        if path.exists() and path.is_file():
            frame = load_one_event_file(path)
            if not frame.empty:
                frames.append(frame)
                loaded.append(name)
    if not frames:
        return pd.DataFrame(), loaded
    events = pd.concat(frames, ignore_index=True, sort=False)

    # Prefer stable IDs when present. Otherwise deduplicate exact identical
    # records only, preserving records that differ in timestamp/fields.
    if "event_id" in events.columns:
        with_id = events["event_id"].notna() & events["event_id"].astype(str).str.strip().ne("")
        deduped = events.loc[with_id].drop_duplicates(subset=["event_id"], keep="first")
        without_id = events.loc[~with_id].drop_duplicates(keep="first")
        events = pd.concat([deduped, without_id], ignore_index=True, sort=False)
    else:
        
       events = events.reset_index(drop=True)
    events = events.loc[
    ~events.astype(str).duplicated(keep="first")
].reset_index(drop=True)

    return events, loaded


def clean_artifact_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    if df.empty:
        return df, pd.DataFrame(
            columns=["Field", "Missing values", "Missing %"]
        )

    missing_counts = {}

    for col in df.columns:
        missing_mask = (
            df[col].isna()
            | df[col].astype("string").str.strip().eq("").fillna(False)
        )
        missing_counts[col] = int(missing_mask.sum())

    quality = pd.DataFrame({
        "Field": list(missing_counts.keys()),
        "Missing values": list(missing_counts.values()),
        "Missing %": [
            round(count / len(df) * 100, 2)
            for count in missing_counts.values()
        ],
    })

    return df, quality


def event_features(events: pd.DataFrame) -> pd.DataFrame:
    """Build session- or visitor-level features from actual event logs."""
    if events.empty or "event" not in events.columns:
        return pd.DataFrame()

    group_col = None
    entity_type = None
    for candidate, label in [("visitor_id", "visitor"), ("session_id", "session")]:
        if candidate in events.columns and events[candidate].notna().any():
            group_col, entity_type = candidate, label
            break
    if group_col is None:
        return pd.DataFrame()

    e = events.dropna(subset=[group_col]).copy()
    e[group_col] = e[group_col].astype(str)
    e["_event_name"] = e["event"].fillna("").astype(str).str.strip().str.lower()
    groups = e.groupby(group_col, dropna=False)
    out = groups.size().rename("total_interactions").to_frame()
    out["entity_type"] = entity_type

    event_name = e["_event_name"]
    counts = {
        "quiz_starts": event_name.eq("quiz_started"),
        "quiz_questions_served": event_name.eq("question_served"),
        "quiz_answers_submitted": event_name.eq("answer_submitted"),
        "quizzes_completed": event_name.eq("quiz_completed"),
        "recommendation_clicks": event_name.str.contains(
            r"recommendation.*click|recommendation_clicked|rec_click", regex=True
        ),
        "recommendation_impressions": event_name.str.contains(
            r"recommendation.*impression|recommendation_shown|rec_impression", regex=True
        ),
        "request_errors": event_name.str.contains(r"error|failed|exception", regex=True),
        "rag_fallbacks": event_name.str.contains(r"fallback", regex=True),
    }
    for feature, mask in counts.items():
        out[feature] = e.assign(_mask=mask.astype(int)).groupby(group_col)["_mask"].sum()

    if "is_correct" in e.columns:
        def bool_value(value):
            if pd.isna(value):
                return np.nan
            text = str(value).strip().lower()
            if text in {"true", "1", "yes", "correct"}:
                return 1.0
            if text in {"false", "0", "no", "incorrect"}:
                return 0.0
            return np.nan
        e["_correct"] = e["is_correct"].map(bool_value)
        answer_rows = e["_event_name"].eq("answer_submitted")
        accuracy = e.loc[answer_rows].groupby(group_col)["_correct"].mean()
        out["quiz_accuracy"] = accuracy

    if "language" in e.columns:
        out["preferred_language"] = e.groupby(group_col)["language"].agg(
            lambda s: s.dropna().astype(str).str.lower().mode().iloc[0]
            if not s.dropna().empty else np.nan
        )
    if "latency_ms" in e.columns:
        e["_latency_numeric"] = pd.to_numeric(e["latency_ms"], errors="coerce")
        out["avg_latency_ms"] = e.groupby(group_col)["_latency_numeric"].mean()
    if "difficulty" in e.columns:
        out["difficulty_values_observed"] = e.groupby(group_col)["difficulty"].nunique()

    out = out.reset_index().rename(columns={group_col: "entity_id"})
    out["engagement_score"] = (
        out["total_interactions"]
        + 2 * out["recommendation_clicks"].fillna(0)
        + out["quiz_answers_submitted"].fillna(0)
    )
    return out

def run_clustering(features: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    if features.empty:
        return features, {"status": "not_run", "reason": "No usable visitor/session IDs in the event logs."}

    numeric = [
        c for c in [
            "total_interactions", "quiz_starts", "quiz_questions_served",
            "quiz_answers_submitted", "quizzes_completed", "recommendation_clicks",
            "quiz_accuracy", "avg_latency_ms", "rag_fallbacks", "request_errors",
            "engagement_score",
        ] if c in features.columns
    ]
    usable = [c for c in numeric if pd.to_numeric(features[c], errors="coerce").notna().sum() >= 2
              and pd.to_numeric(features[c], errors="coerce").nunique(dropna=True) > 1]
    if len(features) < 6 or len(usable) < 2:
        return features, {
            "status": "not_run",
            "reason": f"Need at least 6 analysis entities and 2 varying numeric features; found {len(features)} entities and {len(usable)} usable features.",
            "numeric_features": usable,
        }

    matrix = features[usable].apply(pd.to_numeric, errors="coerce")
    matrix = matrix.fillna(matrix.median()).fillna(0)
    scaled = StandardScaler().fit_transform(matrix)
    n_clusters = min(3, len(features) - 1)
    model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = model.fit_predict(scaled)
    out = features.copy()
    out["cluster_id"] = labels
    silhouette = None
    if len(set(labels)) > 1 and len(set(labels)) < len(labels):
        silhouette = float(silhouette_score(scaled, labels))
    metrics = {
        "status": "completed",
        "entity_type": str(out["entity_type"].iloc[0]),
        "entity_count": int(len(out)),
        "cluster_count": int(n_clusters),
        "features_used": usable,
        "silhouette_score": round(silhouette, 4) if silhouette is not None else None,
        "note": "Cluster IDs are statistical groups, not pre-validated personas.",
    }
    return out, metrics

def save_charts(quality: pd.DataFrame, artifacts: pd.DataFrame, features: pd.DataFrame) -> list[str]:
    made = []
    if not quality.empty:
        q = quality.sort_values("Missing %", ascending=False).head(15).sort_values("Missing %")
        plt.figure(figsize=(10, 6))
        plt.barh(q["Field"], q["Missing %"])
        plt.xlabel("Missing values (%)")
        plt.title("Artifact metadata completeness")
        plt.tight_layout()
        path = OUTPUT_DIR / "artifact_metadata_completeness.png"
        plt.savefig(path, dpi=150)
        plt.close()
        made.append(path.name)

    class_col = next((c for c in ["Project Class", "Class", "class"] if c in artifacts.columns), None)
    if class_col and not artifacts.empty:
        counts = artifacts[class_col].fillna("Unknown").astype(str).value_counts().head(15)
        plt.figure(figsize=(10, 6))
        plt.barh(counts.index[::-1], counts.values[::-1])
        plt.xlabel("Artifact records")
        plt.title("Artifacts by class")
        plt.tight_layout()
        path = OUTPUT_DIR / "artifacts_by_class.png"
        plt.savefig(path, dpi=150)
        plt.close()
        made.append(path.name)

    if not features.empty and "preferred_language" in features.columns:
        counts = features["preferred_language"].fillna("Unknown").value_counts()
        plt.figure(figsize=(7, 5))
        plt.bar(counts.index.astype(str), counts.values)
        plt.ylabel("Analysis entities")
        plt.title("Observed language by visitor/session")
        plt.tight_layout()
        path = OUTPUT_DIR / "observed_language_distribution.png"
        plt.savefig(path, dpi=150)
        plt.close()
        made.append(path.name)
    return made

def make_insights(quality: pd.DataFrame, events: pd.DataFrame, features: pd.DataFrame) -> list[str]:
    insights = []
    if not quality.empty:
        for _, row in quality.sort_values("Missing %", ascending=False).head(5).iterrows():
            if row["Missing values"] > 0:
                insights.append(
                    f"Artifact metadata: {row['Missing %']:.1f}% of records have no usable value for {row['Field']}. Review this field before using it in recommendations or quizzes."
                )
    if not events.empty:
        counts = events["event"].fillna("unknown").astype(str).value_counts() if "event" in events.columns else pd.Series(dtype=int)
        insights.append(f"Observed event logs: {len(events)} unique/retained event rows loaded. Event counts: {counts.to_dict()}.")
    if not features.empty and "quiz_accuracy" in features.columns:
        values = pd.to_numeric(features["quiz_accuracy"], errors="coerce").dropna()
        if len(values):
            insights.append(
                f"Quiz accuracy averages {values.mean()*100:.1f}% across {len(values)} analysis entities with recorded correctness. Interpret cautiously; event volume and question difficulty matter."
            )
    if not events.empty and "is_correct" in events.columns:
        answer_mask = events.get("event", pd.Series("", index=events.index)).astype(str).str.lower().eq("answer_submitted")
        answers = events.loc[answer_mask, "is_correct"].dropna().astype(str).str.lower()
        if len(answers):
            correct = answers.isin({"true", "1", "yes", "correct"}).sum()
            insights.append(f"Quiz sample: {int(correct)}/{len(answers)} recorded answers were correct ({correct/len(answers)*100:.1f}%). This is a sample result, not a population estimate.")
    if not events.empty:
        if "latency_ms" not in events.columns:
            insights.append("Operational monitoring: no latency_ms values were found in the loaded event logs, so latency statistics were not computed.")
        if not any(c in events.columns for c in ["error", "error_type", "status_code"]):
            insights.append("Operational monitoring: no structured error/status field was found in the loaded logs, so a reliable error rate was not computed.")
        names = events.get("event", pd.Series("", index=events.index)).fillna("").astype(str).str.lower()
        if not names.str.contains(r"recommendation.*impression|recommendation_shown|rec_impression", regex=True).any():
            insights.append("Recommendation CTR was not computed because recommendation impression events are not present. Log both impressions and clicks first.")
    return insights[:8]

def main() -> None:
    print("=" * 68)
    print("MEMBER 6 — VISITOR BEHAVIOR ANALYTICS & ML PIPELINE")
    print("=" * 68)

    artifacts, artifact_source = load_artifacts()
    artifacts, quality = clean_artifact_data(artifacts)
    if not artifacts.empty:
        artifacts.to_csv(OUTPUT_DIR / "clean_artifact_analytics_dataset.csv", index=False)
        quality.to_csv(OUTPUT_DIR / "artifact_data_quality.csv", index=False)

    events, event_sources = load_events()
    if not events.empty:
        events.to_csv(OUTPUT_DIR / "combined_clean_event_logs.csv", index=False)

    features = event_features(events)
    clustered, cluster_metrics = run_clustering(features)
    if not features.empty:
        features.to_csv(OUTPUT_DIR / "visitor_or_session_features.csv", index=False)
    if not clustered.empty:
        clustered.to_csv(OUTPUT_DIR / "visitor_or_session_analytics_dataset.csv", index=False)

    charts = save_charts(quality, artifacts, features)
    insights = make_insights(quality, events, features)
    event_counts = {}
    if not events.empty and "event" in events.columns:
        event_counts = {str(k): int(v) for k, v in events["event"].fillna("unknown").astype(str).value_counts().items()}

    report = {
        "artifact_source": artifact_source,
        "clean_artifact_records": int(len(artifacts)),
        "event_sources_loaded": event_sources,
        "real_event_rows_loaded": int(len(events)),
        "visitor_or_session_feature_rows": int(len(features)),
        "analysis_entity_type": str(features["entity_type"].iloc[0]) if not features.empty else "unavailable",
        "event_counts_by_type": event_counts,
        "clustering": cluster_metrics,
        "charts_generated": charts,
        "insights": insights,
        "limitations": [
            "Artifact metadata is not visitor behavior data.",
            "No synthetic visitor records or hard-coded operational metrics are generated.",
            "A session is not equivalent to a unique visitor.",
            "Recommendation CTR requires both impression and click events.",
            "Latency and error rates require corresponding operational log fields.",
            "Retrieval MRR requires labeled relevance judgments.",
        ],
    }
    (OUTPUT_DIR / "member6_analytics_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# Member 6 — Visitor Behavior Analytics Report",
        "",
        f"- Artifact source: `{artifact_source or 'not found'}`",
        f"- Clean artifact records: **{len(artifacts)}**",
        f"- Event files loaded: `{', '.join(event_sources) if event_sources else 'none'}`",
        f"- Real event rows loaded: **{len(events)}**",
        f"- Visitor/session feature rows: **{len(features)}**",
        f"- Analysis entity type: **{report['analysis_entity_type']}**",
        f"- Event types: `{json.dumps(event_counts, ensure_ascii=False)}`",
        "",
        "## Data quality",
        "",
        "| Field | Missing values | Missing % |",
        "|---|---:|---:|",
    ]
    for _, row in quality.iterrows():
        lines.append(f"| {row['Field']} | {int(row['Missing values'])} | {row['Missing %']:.2f}% |")
    lines += [
        "",
        "## Visitor clustering",
        "",
        "```json",
        json.dumps(cluster_metrics, ensure_ascii=False, indent=2),
        "```",
        "",
        "## Actionable insights",
        "",
    ]
    lines += [f"{i}. {item}" for i, item in enumerate(insights, 1)] or ["No insights generated because no relevant source data was available."]
    lines += ["", "## Limitations and integration notes", ""] + [f"- {item}" for item in report["limitations"]]
    (OUTPUT_DIR / "member6_analytics_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Artifact source: {artifact_source or 'not found'}")
    print(f"Clean artifact records: {len(artifacts)}")
    print(f"Event sources loaded: {event_sources}")
    print(f"Real event rows loaded: {len(events)}")
    print(f"Visitor/session feature rows: {len(features)}")
    print(f"Clustering status: {cluster_metrics.get('status')}")
    if cluster_metrics.get("status") == "not_run":
        print(f"Clustering reason: {cluster_metrics.get('reason')}")
    print(f"Charts generated: {charts}")
    print(f"Outputs saved in: {OUTPUT_DIR}")
    print("Member 6 pipeline completed.")

if __name__ == "__main__":
    main()
