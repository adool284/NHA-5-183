"""
Member 4 - Adaptive Museum Quiz (v1.1.0)

What this module does
---------------------
* Generates multiple-choice questions ONLY about artifacts the visitor visited.
* Every correct fact is validated against the artifact's own "RAG Text"
  (the trusted knowledge-base record) before a question is served.
* Facts the museum marks as uncertain (e.g. "Granite (?)") are never used.
* Distractors that could also be correct (e.g. "Middle Kingdom" for
  "Late Middle Kingdom") are filtered out.
* Sessions are plain JSON-serialisable dicts, so they can live behind FastAPI.
* Quiz events are produced in the field format Member 6 needs.

Public API (all inputs/outputs are JSON-friendly dicts)
-------------------------------------------------------
    start_quiz_session(visited_artifact_ids, language="en", voice_used=False, seed=None)
    generate_quiz_question(session)          -> public question dict (no answer inside)
    submit_answer(session, user_answer)      -> result dict (correct answer + evidence)
    get_quiz_summary(session)
    finish_quiz(session)                     -> summary + quiz_completed event

Distractor values come from the wider curated dataset (they are plausible
wrong values, not claims about visited artifacts). Pass
distractor_scope="visited" to start_quiz_session to restrict them to visited
artifacts; the module falls back to the dataset when too few exist and
records which scope was used in each question.
"""

import json
import random
import re
import uuid
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path

import pandas as pd

MODULE_VERSION = "1.1.0"
DATASET_PATH = Path(__file__).resolve().parent / "combined_rag_dataset.csv"

LEVELS = ["easy", "medium", "hard"]
QUESTION_FIELDS = {
    "easy": ["Class", "Material", "Period"],
    "medium": ["Period", "Dynasty", "Material"],
    "hard": ["Dynasty", "Period", "Material"],
}
ALL_FIELDS = ["Class", "Material", "Period", "Dynasty"]
# CSV column that holds each field (the RAG Text line uses the key in ALL_FIELDS)
FIELD_COLUMN = {"Class": "Project Class", "Material": "Material",
                "Period": "Period", "Dynasty": "Dynasty"}

TEMPLATES = {
    "en": {
        "Class": "What type of object is '{title}'?",
        "Material": "What material is '{title}' made of?",
        "Period": "Which historical period does '{title}' belong to?",
        "Dynasty": "Which dynasty does '{title}' belong to?",
    },
    "ar": {
        "Class": "ما نوع القطعة '{title}'؟",
        "Material": "من أي مادة صُنعت القطعة '{title}'؟",
        "Period": "إلى أي فترة تاريخية تنتمي القطعة '{title}'؟",
        "Dynasty": "إلى أي أسرة تنتمي القطعة '{title}'؟",
    },
}
SUPPORTED_LANGUAGES = set(TEMPLATES)

# ----------------------------------------------------------------------------
# Dataset
# ----------------------------------------------------------------------------
_DF = None


def clean_value(value):
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return None
    value = str(value).strip()
    if not value or value.casefold() in {"nan", "none", "null", "unknown", "n/a"}:
        return None
    return value


def normalize_answer(value):
    cleaned = clean_value(value)
    return " ".join(cleaned.casefold().split()) if cleaned else ""


def is_uncertain(value):
    """Museum-marked uncertainty such as 'Granite (?)' must not be quizzed."""
    return value is None or "?" in value


def pretty(value):
    return value.replace("_", " ") if value else value


def get_dataset():
    global _DF
    if _DF is None:
        if not DATASET_PATH.exists():
            raise FileNotFoundError(f"Dataset not found: {DATASET_PATH}")
        data = pd.read_csv(DATASET_PATH)
        required = {"Artifact ID", "Title", "Project Class", "Material", "Period",
                    "Dynasty", "Source URL", "RAG Text"}
        missing = required - set(data.columns)
        if missing:
            raise ValueError(f"Missing required dataset columns: {sorted(missing)}")
        data["Artifact ID"] = data["Artifact ID"].apply(clean_value)
        _DF = data
    return _DF


# ----------------------------------------------------------------------------
# Fact validation against the knowledge base
# ----------------------------------------------------------------------------
def validate_fact(row, field, value):
    """True only if the RAG Text record itself states 'Field: value'."""
    rag_text = clean_value(row.get("RAG Text")) or ""
    wanted = f"{field}: {value}".casefold()
    return any(line.strip().casefold() == wanted for line in rag_text.splitlines())


# ----------------------------------------------------------------------------
# Distractor conflict + similarity
# ----------------------------------------------------------------------------
def _tokens(value):
    return set(re.findall(r"[a-z0-9]+", normalize_answer(value)))


def _dynasty_numbers(value):
    text = normalize_answer(value)
    numbers = set()
    for a, b in re.findall(r"(\d+)\s*[–-]\s*(\d+)", text):
        a, b = int(a), int(b)
        if a <= b <= a + 30:
            numbers.update(range(a, b + 1))
    numbers.update(int(n) for n in re.findall(r"\d+", text))
    return numbers


def conflicts(field, correct, other):
    """True if `other` could also be a correct answer for the same artifact."""
    ta, tb = _tokens(correct), _tokens(other)
    if not ta or not tb or ta <= tb or tb <= ta:
        return True
    if field == "Dynasty" and _dynasty_numbers(correct) & _dynasty_numbers(other):
        return True
    return False


def _similarity(a, b):
    return SequenceMatcher(None, normalize_answer(a), normalize_answer(b)).ratio()


def _value_pool(df, field):
    """Distinct, certain values for a field: {normalized: value}."""
    column = FIELD_COLUMN[field]
    pool = {}
    for raw in df[column]:
        value = clean_value(raw)
        if value and not is_uncertain(value):
            pool.setdefault(normalize_answer(value), value)
    return pool


def pick_distractors(df, field, correct, level, rng, visited_values, scope):
    pool = _value_pool(df, field)
    scope_used = "dataset"
    if scope == "visited":
        visited_pool = {k: v for k, v in pool.items() if k in visited_values}
        usable = [v for v in visited_pool.values() if not conflicts(field, correct, v)]
        if len(usable) >= 3:
            candidates, scope_used = usable, "visited"
        else:
            candidates = [v for v in pool.values() if not conflicts(field, correct, v)]
    else:
        candidates = [v for v in pool.values() if not conflicts(field, correct, v)]
    if len(candidates) < 3:
        return None, scope_used

    ranked = sorted(candidates, key=lambda v: _similarity(correct, v))  # least -> most similar
    if level == "easy":
        window = ranked[: max(3, len(ranked) // 2)]        # clearly different values
    elif level == "hard":
        window = ranked[-max(3, min(12, len(ranked))):]    # most similar plausible values
    else:
        window = ranked
    return rng.sample(window, 3), scope_used


# ----------------------------------------------------------------------------
# Events for Member 6 (JSON-friendly)
# ----------------------------------------------------------------------------
def _log(session, event, **fields):
    record = {
        "event": event,
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "session_id": session["session_id"],
        "language": session["language"],
        "voice_used": session["voice_used"],
        "module_version": MODULE_VERSION,
    }
    record.update(fields)
    session["events"].append(record)
    return record


def export_events_jsonl(session, path):
    """Append the session's events to a JSONL file (one JSON object per line)."""
    with open(path, "a", encoding="utf-8") as file:
        for record in session["events"]:
            file.write(json.dumps(record, ensure_ascii=False) + "\n")


# ----------------------------------------------------------------------------
# Session / question flow
# ----------------------------------------------------------------------------
def start_quiz_session(visited_artifact_ids, language="en", voice_used=False,
                       seed=None, distractor_scope="dataset"):
    """Start a quiz. `visited_artifact_ids` must be the visitor's real visited IDs."""
    if not visited_artifact_ids:
        raise ValueError("Actual visited artifact IDs must be provided.")
    if language not in SUPPORTED_LANGUAGES:
        raise ValueError(f"Unsupported language '{language}'. Use one of {sorted(SUPPORTED_LANGUAGES)}.")
    if distractor_scope not in {"dataset", "visited"}:
        raise ValueError("distractor_scope must be 'dataset' or 'visited'.")

    df = get_dataset()
    requested = list(dict.fromkeys(
        clean_value(item) for item in visited_artifact_ids if clean_value(item)))
    found = set(df["Artifact ID"].dropna())
    artifact_ids = [item for item in requested if item in found]
    missing = [item for item in requested if item not in found]
    if not artifact_ids:
        raise ValueError("None of the supplied artifact IDs exist in the dataset.")

    session = {
        "session_id": uuid.uuid4().hex[:12],
        "language": language,
        "voice_used": bool(voice_used),
        "seed": seed if seed is not None else random.SystemRandom().randrange(2**31),
        "distractor_scope": distractor_scope,
        "artifact_ids": artifact_ids,
        "missing_ids": missing,
        "level": "easy",
        "questions_answered": 0,
        "correct_answers": 0,
        "consecutive_correct": 0,
        "asked": [],          # [[artifact_id, field], ...] never repeated
        "skipped_facts": [],  # facts rejected by uncertainty/validation (for audit)
        "pending": None,      # server-side question incl. correct answer
        "finished": False,
        "events": [],
    }
    _log(session, "quiz_started", artifact_count=len(artifact_ids),
         missing_ids=missing, difficulty=session["level"])
    return session


def _rng(session):
    return random.Random(f"{session['seed']}:{len(session['asked'])}")


def _candidate_facts(session):
    """All (artifact row, field, value) facts that are certain, validated and unasked."""
    df = get_dataset()
    asked = {tuple(item) for item in session["asked"]}
    rows = df[df["Artifact ID"].isin(session["artifact_ids"])]
    facts = []
    for row in rows.to_dict("records"):
        for field in ALL_FIELDS:
            if (row["Artifact ID"], field) in asked:
                continue
            value = clean_value(row.get(FIELD_COLUMN[field]))
            if value is None:
                continue
            if is_uncertain(value):
                note = [row["Artifact ID"], field, "uncertain_value"]
            elif not validate_fact(row, field, value):
                note = [row["Artifact ID"], field, "not_in_rag_text"]
            else:
                facts.append((row, field, value))
                continue
            if note not in session["skipped_facts"]:
                session["skipped_facts"].append(note)
    return facts


def generate_quiz_question(session):
    """
    Return the next question (public view, without the answer) or
    {"status": "no_more_questions"} when every validated fact was asked.
    """
    if session["finished"]:
        return {"status": "quiz_finished"}
    if session["pending"] is not None:
        return _public(session["pending"])  # unanswered question stays the same

    df = get_dataset()
    rng = _rng(session)
    level = session["level"]
    facts = _candidate_facts(session)
    if not facts:
        return {"status": "no_more_questions", "summary": get_quiz_summary(session)}

    preferred = QUESTION_FIELDS[level]
    facts.sort(key=lambda f: (preferred.index(f[1]) if f[1] in preferred else len(preferred)))
    best_rank = (preferred.index(facts[0][1]) if facts[0][1] in preferred else len(preferred))
    tier = [f for f in facts
            if (preferred.index(f[1]) if f[1] in preferred else len(preferred)) == best_rank]
    rng.shuffle(tier)
    visited_rows = df[df["Artifact ID"].isin(session["artifact_ids"])]

    rest = [f for f in facts if all(f is not t for t in tier)]
    for row, field, value in tier + rest:
        visited_values = {normalize_answer(clean_value(v))
                          for v in visited_rows[FIELD_COLUMN[field]] if clean_value(v)}
        distractors, scope_used = pick_distractors(
            df, field, value, level, rng, visited_values, session["distractor_scope"])
        if distractors is None:
            continue
        options = [pretty(v) for v in distractors] + [pretty(value)]
        rng.shuffle(options)
        title = clean_value(row.get("Title")) or "this artifact"
        question = {
            "question_id": f"{session['session_id']}-{len(session['asked']) + 1}",
            "status": "ok",
            "artifact_id": row["Artifact ID"],
            "title": title,
            "field": field,
            "question": TEMPLATES[session["language"]][field].format(title=title),
            "options": options,
            "difficulty": level,
            "language": session["language"],
            "distractor_scope_used": scope_used,
            # server-side only (removed by _public)
            "_correct_answer": pretty(value),
            "_source": {
                "artifact_id": row["Artifact ID"],
                "source_url": clean_value(row.get("Source URL")),
                "evidence": clean_value(row.get("RAG Text")),
                "fact_field": field,
                "fact_value": value,
                "validated_against": "RAG Text",
            },
        }
        session["pending"] = question
        session["asked"].append([row["Artifact ID"], field])
        _log(session, "question_served", question_id=question["question_id"],
             artifact_id=row["Artifact ID"], field=field, difficulty=level)
        return _public(question)

    return {"status": "no_more_questions", "summary": get_quiz_summary(session)}


def _public(question):
    return {k: v for k, v in question.items() if not k.startswith("_")}


def check_answer(question, user_answer):
    """Server-side check against a stored question (includes `_correct_answer`)."""
    if question is None:
        return False
    options = {normalize_answer(o) for o in question["options"]}
    value = normalize_answer(user_answer)
    return value in options and value == normalize_answer(question["_correct_answer"])


def submit_answer(session, user_answer):
    question = session["pending"]
    if question is None:
        return {"valid_answer": False, "message": "No pending question. Call generate_quiz_question first."}
    options = {normalize_answer(o) for o in question["options"]}
    if normalize_answer(user_answer) not in options:
        return {"valid_answer": False, "message": "Invalid answer. Choose one of the options."}

    is_correct = check_answer(question, user_answer)
    session["questions_answered"] += 1
    previous_level = session["level"]
    index = LEVELS.index(previous_level)
    if is_correct:
        session["correct_answers"] += 1
        session["consecutive_correct"] += 1
        if session["consecutive_correct"] >= 2:
            session["level"] = LEVELS[min(index + 1, len(LEVELS) - 1)]
            session["consecutive_correct"] = 0
    else:
        session["consecutive_correct"] = 0
        session["level"] = LEVELS[max(index - 1, 0)]

    session["pending"] = None
    _log(session, "answer_submitted", question_id=question["question_id"],
         artifact_id=question["artifact_id"], field=question["field"],
         is_correct=is_correct, difficulty=previous_level,
         score=session["correct_answers"], answered=session["questions_answered"])
    return {
        "valid_answer": True,
        "is_correct": is_correct,
        "correct_answer": question["_correct_answer"],
        "source": question["_source"],
        "previous_level": previous_level,
        "current_level": session["level"],
    }


def get_quiz_summary(session):
    total = session["questions_answered"]
    correct = session["correct_answers"]
    return {
        "session_id": session["session_id"],
        "questions_answered": total,
        "correct_answers": correct,
        "accuracy_percentage": round(correct / total * 100, 2) if total else 0.0,
        "current_level": session["level"],
        "finished": session["finished"],
    }


def finish_quiz(session):
    if not session["finished"]:
        session["finished"] = True
        session["pending"] = None
        summary = get_quiz_summary(session)
        _log(session, "quiz_completed", score=summary["correct_answers"],
             answered=summary["questions_answered"],
             accuracy_percentage=summary["accuracy_percentage"])
    return get_quiz_summary(session)


def display_question(question):
    print(f"\nDifficulty: {question['difficulty']}")
    print(f"Artifact: {question['title']} ({question['artifact_id']})")
    print(question["question"])
    for index, option in enumerate(question["options"], start=1):
        print(f"{index}. {option}")


if __name__ == "__main__":
    # Runnable example. These 4 IDs are only an example visited list.
    demo_ids = ["MET_2021.41.2", "MET_2021.41.15", "MET_2021.41.18", "MET_2021.41.106"]
    demo = start_quiz_session(demo_ids, language="en", seed=7)
    q = generate_quiz_question(demo)
    display_question(q)
    result = submit_answer(demo, q["options"][0])
    print("Result:", {k: result[k] for k in ("is_correct", "correct_answer", "current_level")})
    print("Source:", result["source"]["source_url"])
    print("Summary:", finish_quiz(demo))
    print("Events logged:", [e["event"] for e in demo["events"]])
